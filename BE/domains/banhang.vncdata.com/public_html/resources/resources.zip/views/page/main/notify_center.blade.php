<div id="notify_center" class="notify_center">
    <div class="notify_center_header clearfix">
        <span id="btn_close_notify_center"><i class="fa fa-arrow-left"></i></span>
        <span>Trung tâm thông báo</span>
    </div>
    <div class="notify_center_body">

    </div>
</div>
