<html>
<head>
    <title>404 Không tìm thấy trang</title>
    <meta charset="utf-8">
</head>
<body>
<div style="text-align: center">
    <h1>404</h1>
    <h3>Không tìm thấy trang này</h3>
</div>
</body>
</html>